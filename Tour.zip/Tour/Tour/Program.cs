﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tour
{
    public class TourOperator
    { /*implements Dictionary*/ // classe Tour

        private string nextClientCode;          //dichiaro le variabili per il codice
        char carCode;
        int numCode;
        Dictionary<string, Client> dizionario = new Dictionary<string, Client>();           //creo il dizionario
        public TourOperator(string initialClientCode)       //costruttore che prende in input il codice iniziale
        {
            string tmp;
            nextClientCode = initialClientCode;
            carCode = nextClientCode[0];
            tmp = nextClientCode[1].ToString() + nextClientCode[2].ToString() + nextClientCode[3].ToString();
            numCode = Convert.ToInt32(tmp);
        }
        public void add(string nome, string dest)       //metodo per aggiungere elementi al dizionario
        {
            Client cliente = new Client(nome, dest);
            dizionario.Add(nextClientCode, cliente);
            incrementoCode();

        }
        private void incrementoCode()           //metodo per il corretto incremento del codice
        {
            int tmp;
            if (numCode < 999)
                numCode++;
            else
            {
                numCode = 0;
                tmp = carCode;
                tmp++;
                carCode = Convert.ToChar(tmp);

            }
            nextClientCode = carCode + numCode.ToString();
        }
        public string toString()        //metodo per la visualizzazione degli elementi
        {
            string tmp = "";
            if (dizionario.Count > 0)
                foreach (KeyValuePair<string, Client> key in dizionario)
                    tmp += key.Key + ":" + key.Value.ToString() + "\n";
            else throw new Exception();
            return tmp;
        }
        public static void Main(string[] args)
        {
            string tmp;
            string[] tmp2;              //dichiaro le variabili utli al programma
            TourOperator tour;
            bool ok = false;
            do
            {

                Console.WriteLine("Inserisci il codice iniziale, del formato %Cnnn%");

                tmp = Console.ReadLine();
                if (tmp.Length == 4)
                    if (char.IsUpper(tmp[0]) && char.IsDigit(tmp[1]) && char.IsDigit(tmp[2]) && char.IsDigit(tmp[3]))
                    {
                        ok = true;                  //con i dovuti controlli vado a instaziare il TourOperator
                    }
                    else
                        Console.WriteLine("Rispettare il formato %Cnnn%");
                else
                    Console.WriteLine("Rispettare il formato %Cnnn%");
            } while (ok == false);

            tour = new TourOperator(tmp);
            while (true)
            {
                Console.WriteLine("Cosa vuoi fare?");
                Console.WriteLine("[1]Inserisci");                  //chiedo cosa si voglia fare in un while
                Console.WriteLine("[2]visualizza");
                tmp = Console.ReadLine();
                switch (tmp)
                {
                    case "1":
                        Console.WriteLine("Inserisci il nome e destinazione con formato %nome:destinazione%");
                        tmp = Console.ReadLine();                   //Nel case 1 mi occuupo dell'inserimento
                        try
                        {
                            tmp2 = tmp.Split(':');
                            tour.add(tmp2[0], tmp2[1]);
                        }
                        catch
                        {
                            Console.WriteLine("Rispettare il formato %nome:destinazione%");
                        }

                        break;
                    case "2":
                        try
                        {
                            Console.WriteLine(tour.toString());
                        }
                        catch                                      //nel case 2 mi occupo del visualizza
                        {
                            Console.WriteLine("Nessun elemento presente");
                        }
                        break;

                }

            }



        }
        // classi interne
        private class Client
        {
            String name; // nome del cliente
            String dest; // destinazione del viaggio
            public Client(String aName, String aDest)
            {
                name = aName;
                dest = aDest;
            }
            public override string ToString()
            {
                return name + ":" + dest;
            }
        }
        private class Coppia /*implements Comparable*/
        {
            String code;
            Client client;
            Coppia(String aCode, Client aClient)
            {
                code = aCode;
                client = aClient;
            }
            //public int compareTo(Object obj)  ???
            //{
            //    Coppia tmpC = (Coppia)obj;
            //    return code.compareTo(tmpC.code);
            //}
        }
    }
}
